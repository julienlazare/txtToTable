<?php 
	//path of the folder where the files (txt and csv) are read and written
	define('FOLDER', 'files/'); 
?>
