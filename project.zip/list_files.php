<?php include_once('index.php'); ?>
<table border="1">
  	<tr>
  		<th colspan="3">Files</th>
	</tr>
	<?php
		$directory = dir(FOLDER);
		
		//list files in the folder
		while($file = $directory->read()){
		
			if (($file == ".")||($file == "..")) continue;
			
			echo '<tr>';
				echo '<td>'.$file.'</td>';
				echo '<td align="center"><a href="read_file.php?file='.$file.'">open</a></td>';
				echo '<td align="center"><a href="delete_file.php?file='.$file.'">delete</a></td>';
			echo '</tr>';
		}
		
		$directory->close();
	?>
</table>

