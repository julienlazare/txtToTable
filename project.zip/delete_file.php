<?php
	include_once('index.php');
	
	$file_name = '';
	
	$file_name = @$_GET['file'];
	
	//if file exist delete
	if (!@unlink(FOLDER.$file_name)){
		echo 'Error deleting '.$file_name;
	}else{
	  	echo 'Deleted '.$file_name;
	}
?>
