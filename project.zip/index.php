<?php include_once('folder_files.php'); ?>
<table border="1">
	<tr>
		<th colspan="3">Menu</th>
	</tr>
	<tr>
		<td><a href="list_files.php">List Files</a></td>
		<td><a href="upload_file.php">Upload Files</a></td>
		<td><a href="read_file.php">Read Files</a></td>
	</tr>
</table>
<br />
