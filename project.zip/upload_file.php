<?php include_once('index.php'); ?>
<form enctype="multipart/form-data" action="" method="POST">
	<!-- MAX_FILE_SIZE maximum filesize accepted by PHP (don't remove)-->
	<!-- 10485760 bytes = 10 Megabytes -->
	<input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
	<table border="1">
		<tr>
			<th>Upload file:</th> 
			<td><input name="file" type="file" accept=".csv, .txt"/></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" value="Upload" /></td>
		</tr>
	</table> 
</form>
<?php
	if($_POST){
		
		//increase size until 10 MB of upload file in the configs PHP
		ini_set('post_max_size', '10M');
		ini_set('upload_max_filesize', '10M');
		
		//path where the file is saved
		$uploadfile = FOLDER . basename($_FILES['file']['name']);
		
		//move file from folder temporarily (tmp_name) to specific folder
		if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
			 echo "File uploaded successfully";
		}else{
			 echo "Error upload";
		}

	}
?>
