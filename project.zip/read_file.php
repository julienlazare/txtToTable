<?php 
	include_once('index.php');

	if($_POST){
		
		//increase PHP Memory Limit (-1 no limit)
		ini_set('memory_limit', '-1');
		
		//to deal with Mac line endings
		ini_set("auto_detect_line_endings", true);
		
		
		//the optional delimiter parameter sets the field delimiter (one character only). 
		$delimiter = $_POST['delimiter'];
		
		//the optional enclosure parameter sets the field enclosure character (one character only). 
		$enclosure = $_POST['enclosure'];
		
		$file_name  = str_replace(".txt", "", str_replace(".csv", "", $_POST['file']));
		$file_name .= $_POST['extension'];

		//open file for reading
		$f = fopen(FOLDER.$file_name, 'r');
	
		if ($f) { 

			//get header
		 	$header = ($enclosure == '')? fgetcsv($f, 0, $delimiter) : fgetcsv($f, 0, $delimiter, $enclosure);

		 	//read file line by line
		 	while (!feof($f)) { 

		     	//reading a file line
		      $line = ($enclosure == '')? fgetcsv($f, 0, $delimiter) : fgetcsv($f, 0, $delimiter, $enclosure);
		     	
		   	if (!$line) continue;

		     	//riding register with indexed values for the header
		     	$register[] = array_combine($header, $line);

		 	}
		 
		 	fclose($f);
		 	
		 	//test on error
			//echo '<pre>';
			//print_r($register);
			//exit;
?>
			<table border="1">
			  	<tr>
					<?php 
						//header
						foreach ($header as $value) { 
							echo '<th>'.$value.'</th>';  
						}	
					?>
			  	</tr>
			  		<?php 
			  			//body
						foreach ($register as $key => $content) { 
							echo '<tr>';
								foreach ($content as $value) { 
									echo '<td>'.$value.'</td>';
								}
							echo '</tr>';
						}	
					?>
			</table>
<?php 
		}
		exit;
	}
	
	$file_name = '';
	
	$file_name = @$_GET['file'];
	
	//get file extension
	$ext = substr($file_name,-4); 
	
	if(($ext != '.txt') && ($ext != '.csv')) $ext = '';
	
?>
<form action="" method="POST">
	<table border="1">
	  	<tr>
	  		<th>File Name:</th>
	  		<td><input type="text" name="file" value="<?php echo $file_name ?>"></td>
		</tr>
		<tr>
			<th>Extension:</th>
			<td>
		  		<select name="extension">
					<option <?php echo ($ext == '')? 'selected' : '' ?> value=""></option>
					<option <?php echo ($ext == '.csv')? 'selected' : '' ?> value=".csv">csv</option>
					<option <?php echo ($ext == '.txt')? 'selected' : '' ?> value=".txt">txt</option>
				</select>
			</td>
		</tr>
		<tr>
	  		<th>Delimiter:</th>
	  		<td><input type="text" name="delimiter" value=","></td>
		</tr>
		<tr>
	  		<th>Enclosure:</th>
	  		<td><input type="text" name="enclosure" value='"'></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" value="Read" /></td>
		</tr>
	</table>
</form>
